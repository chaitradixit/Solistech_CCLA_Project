/* Helper/utility functions used for indexing of CCLA documents.
   Should be included in all Iris pages.
*/
